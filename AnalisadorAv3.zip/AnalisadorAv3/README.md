Compilador Básico Front-end (JFlex + JCup)
Este projeto implementa um front-end básico de compilador, incluindo um analisador léxico (Scanner) com JFlex e um analisador sintático (Parser) com JCup, integrados para processar um código-fonte de exemplo.

Estrutura do Projeto
pgsql
Copiar
Editar
/ANALISADORAV3
├── Compilador/                     # Diretório com código-fonte Java compilado e scripts de teste
│   ├── parser.java
│   ├── parser$CUP$parser$actions.class
│   ├── Scanner.class
│   ├── Scanner.java
│   ├── sym.class
│   ├── sym.java
│   ├── TesteAnalisadorLexico.class
│   ├── TesteAnalisadorLexico.java
│   ├── TesteAnalisadorSintatico.class
│   └── TesteAnalisadorSintatico.java
├── lib/                            # Bibliotecas JFlex e JCup
│   ├── java-cup-11b-runtime.jar
│   ├── java-cup-11b.jar
│   └── jflex-full-1.9.1.jar
├── src/                            # Arquivos-fonte dos analisadores
│   ├── analisador_lexico.flex      # Especificação do Scanner JFlex
│   ├── analisador_sintatico.cup    # Especificação do Parser JCup
│   ├── erro_lexico.txt             # Exemplo com erro léxico
│   ├── erro_sintatico.txt          # Exemplo com erro sintático
│   ├── exemplo_lexico.txt          # Exemplo para teste do analisador léxico
│   └── input.txt                   # Exemplo para teste integrado (Scanner + Parser)
├── README.md                       # Este arquivo
├── run_compilador.bat              # Script para compilar e executar o projeto
├── run_erro.bat                    # Script para testar arquivos com erro
└── Scanner.java~                   # Backup temporário do arquivo Scanner.java
Pré-requisitos
Java Development Kit (JDK) instalado (recomendado JDK 11 ou superior).

JFlex e Java CUP estão incluídos no projeto na pasta lib.

Execução Automatizada (Windows)
O projeto inclui um script batch run_compilador.bat que automatiza o processo de compilação e execução. Este script realiza:

Geração do analisador léxico com JFlex.

Geração do analisador sintático com JCup.

Compilação de todos os arquivos .java.

Execução do analisador léxico com entrada de exemplo.

Execução do analisador sintático com entrada de exemplo.

Demonstração da integração completa entre scanner e parser.

Como executar:
Abra o Visual Studio Code (VS Code)

Navegue até a pasta do projeto ANALISADORAV3

Abra um terminal PowerShell (menu Terminal > Novo Terminal)

Execute o comando:

bash
Copiar
Editar
.\run_compilador.bat
Testes de Erro
Utilize o script run_erro.bat para testar entradas com erros léxicos ou sintáticos.

Os arquivos erro_lexico.txt e erro_sintatico.txt estão na pasta src/.

   ___        _        _ _           _           
  / _ \ _   _| |_ ___ | | | ___  ___| |_ ___ _ __ 
 | | | | | | | __/ _ \| | |/ _ \/ __| __/ _ \ '__|
 | |_| | |_| | || (_) | | |  __/\__ \ ||  __/ |   
  \__\_\\__,_|\__\___/|_|_|\___||___/\__\___|_|   

        PROJETO DESENVOLVIDO POR VICTOR MANUEL
         USO EDUCACIONAL - UNIFOR - ATC 2025
